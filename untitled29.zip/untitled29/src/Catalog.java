import java.util.*;

public class Catalog extends Laptop {

    public Catalog(int id, int ram, int ssd, String os, String color){
        super(id,ram,ssd,os,color);
    }

}